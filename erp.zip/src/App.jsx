import React, { useState, useContext, useEffect } from 'react';
import { AppProvider, AppContext } from './context/AppContext';
import Ecommerce from './pages/Ecommerce';
import Login from './pages/Login';
import AdminPanel from './pages/AdminPanel';

function MainApp() {
  const { currentUser, login, logout } = useContext(AppContext);
  const [currentPage, setCurrentPage] = useState('ecommerce'); // 'ecommerce' | 'login' | 'admin'

  // If a user is already logged in, let's direct them to admin panel if they choose,
  // but if not logged in and they try to go to admin panel, redirect to login
  useEffect(() => {
    if (currentPage === 'admin' && !currentUser) {
      setCurrentPage('login');
    }
  }, [currentPage, currentUser]);

  const handleLoginSuccess = (user) => {
    setCurrentPage('admin');
  };

  const handleLogout = () => {
    logout();
    setCurrentPage('ecommerce');
  };

  return (
    <>
      {currentPage === 'ecommerce' && (
        <Ecommerce onNavigateToLogin={() => setCurrentPage('login')} />
      )}
      
      {currentPage === 'login' && (
        <Login 
          onLoginSuccess={handleLoginSuccess} 
          onNavigateBack={() => setCurrentPage('ecommerce')} 
        />
      )}

      {currentPage === 'admin' && currentUser && (
        <AdminPanel 
          user={currentUser} 
          onLogout={handleLogout} 
          onNavigateToStore={() => setCurrentPage('ecommerce')}
        />
      )}
    </>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}
