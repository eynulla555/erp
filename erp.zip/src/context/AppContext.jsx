import React, { createContext, useState, useEffect } from 'react';

export const AppContext = createContext();

const generateId = (prefix = '') => {
  return `${prefix ? prefix + '-' : ''}${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
};

// Default Mock Data
const defaultUsers = [
  { id: '1', username: 'admin', role: 'admin', name: 'Rəşad Əliyev', password: '123' },
  { id: '2', username: 'satici', role: 'satici', name: 'Leyla Məmmədova', password: '123' },
  { id: '3', username: 'anbardar', role: 'anbardar', name: 'Kamil Həsənov', password: '123' },
  { id: '4', username: 'maliyye', role: 'maliyye', name: 'Nigar Qasımova', password: '123' }
];

const defaultCategories = ['Üzüklər', 'Sırğalar', 'Qolbaqlar', 'Boyunbağılar', 'Aksessuarlar'];

const defaultSuppliers = [
  { id: 's1', name: 'İtalyan Gümüşləri Evi', contact: '+994 50 123 45 67' },
  { id: 's2', name: 'İstanbul Bujuteri Toptan', contact: '+90 212 987 65 43' },
  { id: 's3', name: 'Yerli Əl İşləri İstehsalı', contact: '+994 55 987 65 43' }
];

const defaultProducts = [
  {
    id: 'p1',
    name: 'Zərif Qızılı Üzük (Swarovski)',
    category: 'Üzüklər',
    sku: 'RNG-SW-001',
    purchasePrice: 12.00,
    price: 35.00,
    stock: 15,
    description: 'Qızıl suyuna çəkilmiş, orijinal Swarovski daşları ilə bəzədilmiş incə qadın üzüyü.',
    image: 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=500&auto=format&fit=crop&q=80'
  },
  {
    id: 'p2',
    name: 'İnci Sırğalar (Gümüş 925)',
    category: 'Sırğalar',
    sku: 'EAR-SL-002',
    purchasePrice: 18.00,
    price: 45.00,
    stock: 2, // Low stock for alerts
    description: 'Təbii çay incisi ilə 925 əyar gümüş detallı klassik sırğalar.',
    image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?w=500&auto=format&fit=crop&q=80'
  },
  {
    id: 'p3',
    name: 'Pandora Stilində Minimalist Qolbaq',
    category: 'Qolbaqlar',
    sku: 'BRC-PAN-003',
    purchasePrice: 25.00,
    price: 65.00,
    stock: 8,
    description: 'Minimalist gümüşü qolbaq, müxtəlif talismanlar taxmaq üçün əlverişlidir.',
    image: 'https://images.unsplash.com/photo-1573408301185-9146fe634ad0?w=500&auto=format&fit=crop&q=80'
  },
  {
    id: 'p4',
    name: 'Premium Safir Daşlı Boyunbağı',
    category: 'Boyunbağılar',
    sku: 'NCK-SAP-004',
    purchasePrice: 45.00,
    price: 120.00,
    stock: 4,
    description: 'Mavi safir daş imitasiyalı, axşam ziyafətləri üçün möhtəşəm boyunbağı.',
    image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=500&auto=format&fit=crop&q=80'
  },
  {
    id: 'p5',
    name: 'Kəpənək Naxışlı Zərif Sırğa',
    category: 'Sırğalar',
    sku: 'EAR-BUT-005',
    purchasePrice: 8.00,
    price: 24.00,
    stock: 22,
    description: 'Gənc qızlar üçün sevimli və parlaq kəpənək naxışlı asma sırğa.',
    image: 'https://images.unsplash.com/photo-1630019852942-f89202989a59?w=500&auto=format&fit=crop&q=80'
  }
];

const defaultOrders = [
  {
    id: 'ord-1001',
    customerName: 'Aytən Rzayeva',
    customerPhone: '+994 51 444 33 22',
    address: 'Baku, Yasamal rayonu, İnşaatçılar pr.',
    items: [
      { productId: 'p1', name: 'Zərif Qızılı Üzük (Swarovski)', price: 35.00, qty: 1 }
    ],
    total: 35.00,
    status: 'Gözləmədə',
    date: '2026-05-27T14:30:00.000Z'
  },
  {
    id: 'ord-1002',
    customerName: 'Samir Əhmədov',
    customerPhone: '+994 70 222 11 00',
    address: 'Sumqayıt şəhəri, 9-cu mikrorayon',
    items: [
      { productId: 'p3', name: 'Pandora Stilində Minimalist Qolbaq', price: 65.00, qty: 2 }
    ],
    total: 130.00,
    status: 'Çatdırıldı',
    date: '2026-05-26T10:15:00.000Z'
  }
];

const defaultDebts = [
  {
    id: 'd-1',
    customerName: 'Elnur Qasımov',
    customerPhone: '+994 50 333 44 55',
    totalDebt: 150.00,
    remainingDebt: 90.00,
    dueDate: '2026-06-15',
    status: 'Aktiv',
    payments: [
      { id: 'dp-1', amount: 60.00, date: '2026-05-28T09:00:00.000Z' }
    ]
  },
  {
    id: 'd-2',
    customerName: 'Aysel Məmmədova',
    customerPhone: '+994 77 555 66 77',
    totalDebt: 80.00,
    remainingDebt: 80.00,
    dueDate: '2026-06-05',
    status: 'Aktiv',
    payments: []
  }
];

const defaultTransactions = [
  { id: 't-1', type: 'income', amount: 130.00, category: 'Satış', description: 'ord-1002 nömrəli onlayn sifarişin çatdırılması', date: '2026-05-26T10:15:00.000Z' },
  { id: 't-2', type: 'income', amount: 60.00, category: 'Borc Ödənişi', description: 'Elnur Qasımov qismən borc ödənişi', date: '2026-05-28T09:00:00.000Z' },
  { id: 't-3', type: 'expense', amount: 200.00, category: 'İcarə', description: 'Mağaza icarə haqqı (Aylıq depozit)', date: '2026-05-01T12:00:00.000Z' },
  { id: 't-4', type: 'expense', amount: 50.00, category: 'Mədaxil', description: 'Yeni malların anbara daxil edilməsi', date: '2026-05-25T11:00:00.000Z' }
];

export const AppProvider = ({ children }) => {
  // Load initial data from localStorage if exists, else load defaults
  const [users, setUsers] = useState(() => {
    const saved = localStorage.getItem('erp_users');
    return saved ? JSON.parse(saved) : defaultUsers;
  });

  const [categories, setCategories] = useState(() => {
    const saved = localStorage.getItem('erp_categories');
    return saved ? JSON.parse(saved) : defaultCategories;
  });

  const [suppliers, setSuppliers] = useState(() => {
    const saved = localStorage.getItem('erp_suppliers');
    return saved ? JSON.parse(saved) : defaultSuppliers;
  });

  const [products, setProducts] = useState(() => {
    const saved = localStorage.getItem('erp_products');
    return saved ? JSON.parse(saved) : defaultProducts;
  });

  const [orders, setOrders] = useState(() => {
    const saved = localStorage.getItem('erp_orders');
    return saved ? JSON.parse(saved) : defaultOrders;
  });

  const [debts, setDebts] = useState(() => {
    const saved = localStorage.getItem('erp_debts');
    return saved ? JSON.parse(saved) : defaultDebts;
  });

  const [transactions, setTransactions] = useState(() => {
    const saved = localStorage.getItem('erp_transactions');
    return saved ? JSON.parse(saved) : defaultTransactions;
  });

  const [currentUser, setCurrentUser] = useState(() => {
    const saved = localStorage.getItem('erp_current_user');
    return saved ? JSON.parse(saved) : null;
  });

  // Toasts management
  const [toasts, setToasts] = useState([]);

  const triggerToast = (message, type = 'success') => {
    const id = generateId('toast');
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem('erp_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('erp_categories', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem('erp_suppliers', JSON.stringify(suppliers));
  }, [suppliers]);

  useEffect(() => {
    localStorage.setItem('erp_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('erp_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('erp_debts', JSON.stringify(debts));
  }, [debts]);

  useEffect(() => {
    localStorage.setItem('erp_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('erp_current_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('erp_current_user');
    }
  }, [currentUser]);

  // Auth Operations
  const login = (username, password) => {
    const user = users.find(
      (u) => u.username.toLowerCase() === username.toLowerCase() && u.password === password
    );
    if (user) {
      setCurrentUser(user);
      triggerToast(`Xoş gəldiniz, ${user.name}! (${user.role.toUpperCase()})`);
      return { success: true, user };
    } else {
      triggerToast('İstifadəçi adı və ya parol yanlışdır!', 'danger');
      return { success: false };
    }
  };

  const logout = () => {
    setCurrentUser(null);
    triggerToast('Sistemdən çıxış edildi.');
  };

  // Admin User Operations
  const addUser = (username, name, role, password) => {
    if (users.some((u) => u.username.toLowerCase() === username.toLowerCase())) {
      triggerToast('Bu istifadəçi adı artıq mövcuddur!', 'danger');
      return false;
    }
    const newUser = {
      id: generateId('u'),
      username,
      name,
      role,
      password
    };
    setUsers((prev) => [...prev, newUser]);
    triggerToast(`Yeni əməkdaş qeyd olundu: ${name}`);
    return true;
  };

  const deleteUser = (id) => {
    if (id === currentUser.id) {
      triggerToast('Cari istifadəçini silə bilməzsiniz!', 'danger');
      return false;
    }
    setUsers((prev) => prev.filter((u) => u.id !== id));
    triggerToast('İstifadəçi silindi.');
    return true;
  };

  // Warehouse operations (Goods Receipt)
  const addGoodsReceipt = (productData) => {
    const isExisting = products.find(
      (p) => p.sku.toLowerCase() === productData.sku.toLowerCase() ||
             p.name.toLowerCase() === productData.name.toLowerCase()
    );

    if (isExisting) {
      // Update stock of existing product
      setProducts((prev) =>
        prev.map((p) =>
          p.id === isExisting.id
            ? { ...p, stock: p.stock + parseInt(productData.stock), price: parseFloat(productData.price) }
            : p
        )
      );
      triggerToast(`${isExisting.name} məhsulunun anbar qalığı ${productData.stock} ədəd artırıldı.`);
    } else {
      // Create new product
      const newProduct = {
        id: generateId('p'),
        name: productData.name,
        category: productData.category,
        sku: productData.sku || `SKU-${generateId().slice(-6)}`,
        purchasePrice: parseFloat(productData.purchasePrice),
        price: parseFloat(productData.price),
        stock: parseInt(productData.stock),
        description: productData.description || '',
        image: productData.image || 'https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=500&auto=format&fit=crop&q=80'
      };
      setProducts((prev) => [...prev, newProduct]);
      triggerToast(`Yeni məhsul anbara daxil edildi: ${productData.name}`);
    }

    // Add cost as transaction expense
    const cost = parseFloat(productData.purchasePrice) * parseInt(productData.stock);
    const newTransaction = {
      id: generateId('t'),
      type: 'expense',
      amount: cost,
      category: 'Mədaxil',
      description: `${productData.name} - ${productData.stock} ədəd mədaxil edildi.`,
      date: new Date().toISOString()
    };
    setTransactions((prev) => [newTransaction, ...prev]);
  };

  // Add categories
  const addCategory = (categoryName) => {
    if (categories.includes(categoryName)) {
      triggerToast('Bu kateqoriya artıq mövcuddur!', 'warning');
      return false;
    }
    setCategories((prev) => [...prev, categoryName]);
    triggerToast(`Kateqoriya əlavə edildi: ${categoryName}`);
    return true;
  };

  // Add Supplier
  const addSupplier = (name, contact) => {
    const newSupplier = {
      id: generateId('s'),
      name,
      contact
    };
    setSuppliers((prev) => [...prev, newSupplier]);
    triggerToast(`Yeni tədarükçü qeyd olundu: ${name}`);
  };

  // Customer order creation (E-Commerce Checkout)
  const placeEcommerceOrder = (customerData, cartItems) => {
    const orderId = 'ord-' + Math.floor(1000 + Math.random() * 9000).toString();
    const total = cartItems.reduce((acc, item) => acc + (item.price * item.qty), 0);
    const newOrder = {
      id: orderId,
      customerName: customerData.name,
      customerPhone: customerData.phone,
      address: customerData.address,
      items: cartItems.map(item => ({
        productId: item.id,
        name: item.name,
        price: item.price,
        qty: item.qty
      })),
      total,
      status: 'Gözləmədə',
      date: new Date().toISOString()
    };

    setOrders((prev) => [newOrder, ...prev]);
    triggerToast(`Sifarişiniz qəbul olundu! Sifariş Nömrəsi: ${orderId}`);
    return orderId;
  };

  // Order status update (Admin role)
  const updateOrderStatus = (orderId, status) => {
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id === orderId) {
          // If status changes to 'Çatdırıldı' (Delivered) and wasn't before, we record financial transaction & deduct stock
          if (status === 'Çatdırıldı' && o.status !== 'Çatdırıldı') {
            // Deduct stock for all items
            let stockOk = true;
            o.items.forEach(item => {
              const product = products.find(p => p.id === item.productId);
              if (!product || product.stock < item.qty) {
                stockOk = false;
              }
            });

            if (!stockOk) {
              triggerToast(`Sifariş ${orderId} çatdırıla bilmədi: anbarda kifayət qədər məhsul yoxdur!`, 'danger');
              return o; // don't update status
            }

            // Deduct stocks
            setProducts((prevProd) =>
              prevProd.map((p) => {
                const orderItem = o.items.find(item => item.productId === p.id);
                return orderItem ? { ...p, stock: Math.max(0, p.stock - orderItem.qty) } : p;
              })
            );

            // Record income transaction
            const newTransaction = {
              id: generateId('t'),
              type: 'income',
              amount: o.total,
              category: 'Satış',
              description: `${o.id} nömrəli onlayn sifariş çatdırıldı`,
              date: new Date().toISOString()
            };
            setTransactions((prevT) => [newTransaction, ...prevT]);
            triggerToast(`Sifariş ${orderId} çatdırıldı olaraq qeyd olundu və maliyyəyə əlavə edildi.`);
          }
          return { ...o, status };
        }
        return o;
      })
    );
  };

  // POS / Direct Sales & Debtors Management (Seller role)
  const makePOSSale = (cartItems, saleDetails) => {
    // cartItems: [{id, name, price, qty, purchasePrice}]
    // saleDetails: { isDebt: boolean, customerName: string, customerPhone: string, dueDate: string, paidAmount: number }

    // Check stock
    let stockOk = true;
    cartItems.forEach(item => {
      const prod = products.find(p => p.id === item.id);
      if (!prod || prod.stock < item.qty) {
        stockOk = false;
      }
    });

    if (!stockOk) {
      triggerToast('Satış uğursuz oldu: Anbarda kifayət qədər məhsul yoxdur!', 'danger');
      return false;
    }

    const total = cartItems.reduce((acc, item) => acc + (item.price * item.qty), 0);

    // Deduct stock
    setProducts((prevProd) =>
      prevProd.map((p) => {
        const cartItem = cartItems.find(item => item.id === p.id);
        return cartItem ? { ...p, stock: p.stock - cartItem.qty } : p;
      })
    );

    if (saleDetails.isDebt) {
      // Create a debt record
      const debtAmount = total - parseFloat(saleDetails.paidAmount || 0);
      const newDebt = {
        id: generateId('d'),
        customerName: saleDetails.customerName,
        customerPhone: saleDetails.customerPhone,
        totalDebt: debtAmount,
        remainingDebt: debtAmount,
        dueDate: saleDetails.dueDate || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        status: 'Aktiv',
        payments: []
      };

      // If they paid something upfront, log that transaction
      const upfront = parseFloat(saleDetails.paidAmount || 0);
      if (upfront > 0) {
        newDebt.payments.push({
          id: generateId('dp'),
          amount: upfront,
          date: new Date().toISOString()
        });

        // Record income transaction for the upfront payment
        const transUpfront = {
          id: generateId('t-up'),
          type: 'income',
          amount: upfront,
          category: 'Satış (Qismən)',
          description: `${saleDetails.customerName} - Satış üçün ilkin ödəniş`,
          date: new Date().toISOString()
        };
        setTransactions((prev) => [transUpfront, ...prev]);
      }

      setDebts((prev) => [newDebt, ...prev]);
      triggerToast(`Satış tamamlandı və ${debtAmount} AZN borc qeydə alındı!`);
    } else {
      // Regular instant sale
      const newTransaction = {
        id: generateId('t'),
        type: 'income',
        amount: total,
        category: 'Satış',
        description: 'Mağazadaxili POS satış',
        date: new Date().toISOString()
      };
      setTransactions((prev) => [newTransaction, ...prev]);
      triggerToast(`Satış tamamlandı! Ümumi: ${total} AZN`);
    }

    return true;
  };

  // Debt Payment Processing (Finance role)
  const recordDebtPayment = (debtId, amount) => {
    const paymentAmount = parseFloat(amount);
    if (isNaN(paymentAmount) || paymentAmount <= 0) {
      triggerToast('Düzgün ödəniş məbləği daxil edin!', 'danger');
      return false;
    }

    let debtName = '';
    let isFullyPaid = false;

    setDebts((prevDebts) =>
      prevDebts.map((d) => {
        if (d.id === debtId) {
          debtName = d.customerName;
          const newRemaining = Math.max(0, d.remainingDebt - paymentAmount);
          isFullyPaid = newRemaining === 0;

          return {
            ...d,
            remainingDebt: newRemaining,
            status: isFullyPaid ? 'Ödənilib' : 'Aktiv',
            payments: [
              ...d.payments,
              {
                id: generateId('dp'),
                amount: paymentAmount,
                date: new Date().toISOString()
              }
            ]
          };
        }
        return d;
      })
    );

    // Record Income Transaction
    const newTransaction = {
      id: generateId('t'),
      type: 'income',
      amount: paymentAmount,
      category: 'Borc Ödənişi',
      description: `${debtName} tərəfindən borc ödənişi`,
      date: new Date().toISOString()
    };
    setTransactions((prev) => [newTransaction, ...prev]);

    triggerToast(
      isFullyPaid
        ? `${debtName} borcunu tamamilə bağladı!`
        : `${debtName} borcundan ${paymentAmount} AZN ödədi. Qalan: ${(remainingDebt => remainingDebt - paymentAmount)(remainingDebt => remainingDebt)} AZN`,
      'success'
    );
    return true;
  };

  // Direct Expense Record (Finance / Admin role)
  const addExpense = (amount, category, description) => {
    const expenseAmount = parseFloat(amount);
    if (isNaN(expenseAmount) || expenseAmount <= 0) {
      triggerToast('Düzgün məbləğ daxil edin!', 'danger');
      return false;
    }

    const newTransaction = {
      id: generateId('t'),
      type: 'expense',
      amount: expenseAmount,
      category,
      description,
      date: new Date().toISOString()
    };

    setTransactions((prev) => [newTransaction, ...prev]);
    triggerToast(`Xərc qeydə alındı: ${expenseAmount} AZN (${category})`);
    return true;
  };

  return (
    <AppContext.Provider
      value={{
        users,
        categories,
        suppliers,
        products,
        orders,
        debts,
        transactions,
        currentUser,
        toasts,
        triggerToast,
        login,
        logout,
        addUser,
        deleteUser,
        addGoodsReceipt,
        addCategory,
        addSupplier,
        placeEcommerceOrder,
        updateOrderStatus,
        makePOSSale,
        recordDebtPayment,
        addExpense
      }}
    >
      {children}
      
      {/* Toast Notifications Overlay */}
      <div className="toast-container">
        {toasts.map((toast) => (
          <div key={toast.id} className={`toast toast-${toast.type}`}>
            <span>{toast.message}</span>
          </div>
        ))}
      </div>
    </AppContext.Provider>
  );
};
