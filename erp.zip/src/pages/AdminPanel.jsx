import React, { useContext, useState, useEffect } from 'react';
import { AppContext } from '../context/AppContext';
import { 
  LayoutDashboard, PlusCircle, Package, ShoppingCart, 
  Users, CreditCard, LogOut, Globe, TrendingUp, AlertTriangle, 
  TrendingDown, Check, X, DollarSign, Edit, Trash2, Calendar
} from 'lucide-react';

export default function AdminPanel({ user, onLogout, onNavigateToStore }) {
  const { 
    products, categories, suppliers, orders, debts, transactions, users,
    addGoodsReceipt, addCategory, addSupplier, updateOrderStatus,
    makePOSSale, recordDebtPayment, addExpense, addUser, deleteUser
  } = useContext(AppContext);

  // Set default theme for ERP (Dark Theme fits SaaS visual style)
  useEffect(() => {
    document.body.setAttribute('data-theme', 'dark');
    return () => {
      document.body.removeAttribute('data-theme');
    };
  }, []);

  // Determine available tabs based on role
  const getTabsByRole = () => {
    const allTabs = [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { id: 'receipt', label: 'Malların Mədahili', icon: PlusCircle },
      { id: 'warehouse', label: 'Anbar Siyahısı', icon: Package },
      { id: 'pos', label: 'POS Satış', icon: ShoppingCart },
      { id: 'orders', label: 'Sifarişlər', icon: Globe },
      { id: 'debtors', label: 'Borclular Siyahısı', icon: CreditCard },
      { id: 'finance', label: 'Maliyyə & Hesabatlar', icon: DollarSign },
      { id: 'staff', label: 'Əməkdaşlar', icon: Users }
    ];

    if (user.role === 'admin') return allTabs;
    if (user.role === 'anbardar') {
      return allTabs.filter(t => ['dashboard', 'receipt', 'warehouse'].includes(t.id));
    }
    if (user.role === 'satici') {
      return allTabs.filter(t => ['dashboard', 'pos', 'orders'].includes(t.id));
    }
    if (user.role === 'maliyye') {
      return allTabs.filter(t => ['dashboard', 'debtors', 'finance'].includes(t.id));
    }
    return [];
  };

  const tabs = getTabsByRole();
  const [activeTab, setActiveTab] = useState(tabs[0]?.id || 'dashboard');

  // --- SUB-STATES FOR FORMS ---
  // Receipt Form State
  const [receiptName, setReceiptName] = useState('');
  const [receiptSku, setReceiptSku] = useState('');
  const [receiptCategory, setReceiptCategory] = useState(categories[0] || '');
  const [receiptPurchasePrice, setReceiptPurchasePrice] = useState('');
  const [receiptPrice, setReceiptPrice] = useState('');
  const [receiptStock, setReceiptStock] = useState('');
  const [receiptDesc, setReceiptDesc] = useState('');
  const [receiptImg, setReceiptImg] = useState('');
  const [newCatName, setNewCatName] = useState('');
  const [showNewCatModal, setShowNewCatModal] = useState(false);

  // POS State
  const [posCart, setPosCart] = useState([]);
  const [posSearch, setPosSearch] = useState('');
  const [posIsDebt, setPosIsDebt] = useState(false);
  const [posCustName, setPosCustName] = useState('');
  const [posCustPhone, setPosCustPhone] = useState('');
  const [posPaidUpfront, setPosPaidUpfront] = useState('');
  const [posDueDate, setPosDueDate] = useState('');

  // Debt Payment State
  const [selectedDebtId, setSelectedDebtId] = useState(null);
  const [paymentAmount, setPaymentAmount] = useState('');
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  // Expense State
  const [expAmount, setExpAmount] = useState('');
  const [expCategory, setExpCategory] = useState('İcarə');
  const [expDesc, setExpDesc] = useState('');

  // Staff State
  const [staffUser, setStaffUser] = useState('');
  const [staffName, setStaffName] = useState('');
  const [staffRole, setStaffRole] = useState('satici');
  const [staffPass, setStaffPass] = useState('');

  // --- HANDLERS ---
  const handleAddReceipt = (e) => {
    e.preventDefault();
    addGoodsReceipt({
      name: receiptName,
      sku: receiptSku,
      category: receiptCategory,
      purchasePrice: receiptPurchasePrice,
      price: receiptPrice,
      stock: receiptStock,
      description: receiptDesc,
      image: receiptImg
    });
    // Reset form
    setReceiptName('');
    setReceiptSku('');
    setReceiptPurchasePrice('');
    setReceiptPrice('');
    setReceiptStock('');
    setReceiptDesc('');
    setReceiptImg('');
  };

  const handleAddCategory = (e) => {
    e.preventDefault();
    if (!newCatName) return;
    if (addCategory(newCatName)) {
      setReceiptCategory(newCatName);
      setNewCatName('');
      setShowNewCatModal(false);
    }
  };

  const addToPosCart = (product) => {
    if (product.stock <= 0) return;
    setPosCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        if (existing.qty >= product.stock) return prev;
        return prev.map(item => item.id === product.id ? { ...item, qty: item.qty + 1 } : item);
      }
      return [...prev, { ...product, qty: 1 }];
    });
  };

  const updatePosQty = (productId, qty) => {
    const product = products.find(p => p.id === productId);
    if (qty <= 0) {
      setPosCart(prev => prev.filter(item => item.id !== productId));
      return;
    }
    if (product && qty > product.stock) return;
    setPosCart(prev => prev.map(item => item.id === productId ? { ...item, qty } : item));
  };

  const handlePOSCheckout = (e) => {
    e.preventDefault();
    if (posCart.length === 0) return;

    if (posIsDebt && (!posCustName || !posCustPhone)) {
      alert('Borc satışı üçün müştəri adı və telefonu vacibdir!');
      return;
    }

    const ok = makePOSSale(posCart, {
      isDebt: posIsDebt,
      customerName: posCustName,
      customerPhone: posCustPhone,
      dueDate: posDueDate,
      paidAmount: posPaidUpfront
    });

    if (ok) {
      setPosCart([]);
      setPosCustName('');
      setPosCustPhone('');
      setPosPaidUpfront('');
      setPosDueDate('');
      setPosIsDebt(false);
    }
  };

  const openDebtPaymentModal = (debtId) => {
    setSelectedDebtId(debtId);
    setPaymentAmount('');
    setShowPaymentModal(true);
  };

  const handleRecordPayment = (e) => {
    e.preventDefault();
    if (!selectedDebtId || !paymentAmount) return;
    const ok = recordDebtPayment(selectedDebtId, paymentAmount);
    if (ok) {
      setShowPaymentModal(false);
      setSelectedDebtId(null);
    }
  };

  const handleAddExpense = (e) => {
    e.preventDefault();
    const ok = addExpense(expAmount, expCategory, expDesc);
    if (ok) {
      setExpAmount('');
      setExpDesc('');
    }
  };

  const handleAddStaff = (e) => {
    e.preventDefault();
    const ok = addUser(staffUser, staffName, staffRole, staffPass);
    if (ok) {
      setStaffUser('');
      setStaffName('');
      setStaffPass('');
    }
  };

  // --- STATS CALCULATIONS ---
  const totalSales = transactions
    .filter(t => t.type === 'income' && (t.category.startsWith('Satış') || t.category === 'Borc Ödənişi'))
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpenses = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const netIncome = totalSales - totalExpenses;

  const totalStockCount = products.reduce((sum, p) => sum + p.stock, 0);

  const criticalStockCount = products.filter(p => p.stock <= 3).length;

  const totalRemainingDebt = debts
    .filter(d => d.status === 'Aktiv')
    .reduce((sum, d) => sum + d.remainingDebt, 0);

  return (
    <div className="admin-layout">
      {/* Top Header */}
      <header className="admin-header">
        <div className="admin-header-left">
          <div className="brand-group">
            <h2 className="erp-title">LUMIÈRE</h2>
            <span className="erp-badge">ERP SAAS</span>
          </div>
        </div>
        <div className="admin-header-right">
          <div className="user-profile-info">
            <span className="user-role-badge">{user.role.toUpperCase()}</span>
            <span className="user-name">{user.name}</span>
          </div>
          <button className="btn btn-secondary nav-store-btn" onClick={onNavigateToStore}>
            <Globe size={16} />
            <span>Müştəri Vitrini</span>
          </button>
          <button className="btn btn-danger btn-logout" onClick={onLogout}>
            <LogOut size={16} />
            <span>Çıxış</span>
          </button>
        </div>
      </header>

      {/* Main Container */}
      <div className="admin-main-container">
        
        {/* Sidebar */}
        <aside className="admin-sidebar">
          <nav className="sidebar-nav">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  className={`nav-item ${activeTab === tab.id ? 'active' : ''}`}
                  onClick={() => setActiveTab(tab.id)}
                >
                  <Icon size={20} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </aside>

        {/* Content Area */}
        <main className="admin-content-area">
          
          {/* 1. DASHBOARD TAB */}
          {activeTab === 'dashboard' && (
            <div className="dashboard-view animate-fade">
              <h3 className="section-title">Mağaza İcmalı və Analitika</h3>
              
              {/* Stats Grid */}
              <div className="stats-grid">
                <div className="stat-card card">
                  <div className="stat-icon-wrapper income">
                    <TrendingUp size={24} />
                  </div>
                  <div className="stat-data">
                    <span className="stat-label">Ümumi Gəlirlər</span>
                    <span className="stat-value text-success">{totalSales.toFixed(2)} AZN</span>
                  </div>
                </div>

                <div className="stat-card card">
                  <div className="stat-icon-wrapper expense">
                    <TrendingDown size={24} />
                  </div>
                  <div className="stat-data">
                    <span className="stat-label">Ümumi Xərclər</span>
                    <span className="stat-value text-danger">{totalExpenses.toFixed(2)} AZN</span>
                  </div>
                </div>

                <div className="stat-card card">
                  <div className="stat-icon-wrapper profit">
                    <DollarSign size={24} />
                  </div>
                  <div className="stat-data">
                    <span className="stat-label">Xalis Qazanc</span>
                    <span className={`stat-value ${netIncome >= 0 ? 'text-success' : 'text-danger'}`}>
                      {netIncome.toFixed(2)} AZN
                    </span>
                  </div>
                </div>

                <div className="stat-card card">
                  <div className="stat-icon-wrapper stock">
                    <Package size={24} />
                  </div>
                  <div className="stat-data">
                    <span className="stat-label">Anbarda Qalıq</span>
                    <span className="stat-value">{totalStockCount} ədəd</span>
                  </div>
                </div>

                <div className="stat-card card">
                  <div className="stat-icon-wrapper debt">
                    <CreditCard size={24} />
                  </div>
                  <div className="stat-data">
                    <span className="stat-label">Cəmi Nisyə Borc</span>
                    <span className="stat-value text-warning">{totalRemainingDebt.toFixed(2)} AZN</span>
                  </div>
                </div>
              </div>

              {/* Alert for low stock */}
              {criticalStockCount > 0 && (
                <div className="alert-box alert-warning">
                  <AlertTriangle size={20} />
                  <span>Diqqət! Anbarda <strong>{criticalStockCount} məhsulun</strong> qalığı tükənmək üzrədir (3 və daha az). Zəhmət olmasa tədarük edin.</span>
                </div>
              )}

              {/* Two Column Layout */}
              <div className="dashboard-grid">
                {/* Pending orders */}
                <div className="dashboard-col glass-panel">
                  <div className="col-header">
                    <h4>Yeni Gözləyən Sifarişlər</h4>
                  </div>
                  <div className="col-content">
                    {orders.filter(o => o.status === 'Gözləmədə').length > 0 ? (
                      <div className="mini-list">
                        {orders.filter(o => o.status === 'Gözləmədə').map(o => (
                          <div key={o.id} className="mini-list-item">
                            <div className="item-left">
                              <strong>{o.customerName}</strong>
                              <span>{o.items.map(i => `${i.name} (${i.qty}x)`).join(', ')}</span>
                            </div>
                            <div className="item-right">
                              <span className="price-tag">{o.total.toFixed(2)} AZN</span>
                              {['admin', 'satici'].includes(user.role) && (
                                <div className="action-buttons-row">
                                  <button 
                                    className="btn-action success" 
                                    onClick={() => updateOrderStatus(o.id, 'Çatdırıldı')}
                                    title="Çatdırıldı olaraq qeyd et"
                                  >
                                    <Check size={14} />
                                  </button>
                                  <button 
                                    className="btn-action danger" 
                                    onClick={() => updateOrderStatus(o.id, 'Ləğv edilib')}
                                    title="Ləğv et"
                                  >
                                    <X size={14} />
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="no-data-text">Gözləmədə olan onlayn sifariş yoxdur.</p>
                    )}
                  </div>
                </div>

                {/* Recent Transactions */}
                <div className="dashboard-col glass-panel">
                  <div className="col-header">
                    <h4>Son Tranzaksiyalar</h4>
                  </div>
                  <div className="col-content">
                    {transactions.length > 0 ? (
                      <div className="mini-list">
                        {transactions.slice(0, 5).map(t => (
                          <div key={t.id} className="mini-list-item">
                            <div className="item-left">
                              <strong className={t.type === 'income' ? 'text-success' : 'text-danger'}>
                                {t.type === 'income' ? '+' : '-'}{t.amount.toFixed(2)} AZN
                              </strong>
                              <span>{t.category} - {t.description}</span>
                            </div>
                            <div className="item-right text-muted font-sm">
                              {new Date(t.date).toLocaleDateString()}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="no-data-text">Maliyyə hərəkəti qeydə alınmayıb.</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 2. GOODS RECEIPT TAB */}
          {activeTab === 'receipt' && (
            <div className="receipt-view animate-fade">
              <div className="view-header">
                <h3 className="section-title">Malların Anbara Mədahili</h3>
                <button className="btn btn-secondary" onClick={() => setShowNewCatModal(true)}>
                  Yeni Kateqoriya Yarat
                </button>
              </div>

              <div className="card glass-panel form-card">
                <form onSubmit={handleAddReceipt}>
                  <div className="form-grid">
                    <div className="form-group">
                      <label>Məhsulun Adı *</label>
                      <input 
                        type="text" 
                        className="form-control" 
                        required 
                        value={receiptName}
                        onChange={(e) => setReceiptName(e.target.value)}
                        placeholder="Məs. Swarowski Kristal Üzük"
                      />
                    </div>
                    
                    <div className="form-group">
                      <label>Barkod / SKU (Mövcuddursa)</label>
                      <input 
                        type="text" 
                        className="form-control" 
                        value={receiptSku}
                        onChange={(e) => setReceiptSku(e.target.value)}
                        placeholder="Məs. RNG-SW-105"
                      />
                    </div>

                    <div className="form-group">
                      <label>Kateqoriya *</label>
                      <select 
                        className="form-control" 
                        value={receiptCategory}
                        onChange={(e) => setReceiptCategory(e.target.value)}
                        required
                      >
                        {categories.map(c => (
                          <option key={c} value={c}>{c}</option>
                        ))}
                      </select>
                    </div>

                    <div className="form-group">
                      <label>Məhsul Şəkli (URL)</label>
                      <input 
                        type="url" 
                        className="form-control" 
                        value={receiptImg}
                        onChange={(e) => setReceiptImg(e.target.value)}
                        placeholder="https://example.com/image.jpg"
                      />
                    </div>

                    <div className="form-group">
                      <label>Alış Qiyməti (Maya) - 1 ədəd üçün * (AZN)</label>
                      <input 
                        type="number" 
                        step="0.01"
                        className="form-control" 
                        required 
                        value={receiptPurchasePrice}
                        onChange={(e) => setReceiptPurchasePrice(e.target.value)}
                        placeholder="Məs. 15.50"
                      />
                    </div>

                    <div className="form-group">
                      <label>Satış Qiyməti - 1 ədəd üçün * (AZN)</label>
                      <input 
                        type="number" 
                        step="0.01"
                        className="form-control" 
                        required 
                        value={receiptPrice}
                        onChange={(e) => setReceiptPrice(e.target.value)}
                        placeholder="Məs. 38.00"
                      />
                    </div>

                    <div className="form-group">
                      <label>Mədaxil Miqdarı * (Ədəd)</label>
                      <input 
                        type="number" 
                        className="form-control" 
                        required 
                        value={receiptStock}
                        onChange={(e) => setReceiptStock(e.target.value)}
                        placeholder="Məs. 50"
                      />
                    </div>

                    <div className="form-group col-span-all">
                      <label>Məhsul haqqında qeydlər</label>
                      <textarea 
                        className="form-control" 
                        rows="3"
                        value={receiptDesc}
                        onChange={(e) => setReceiptDesc(e.target.value)}
                        placeholder="Məhsul haqqında əlavə detalları daxil edin..."
                      ></textarea>
                    </div>
                  </div>

                  <button type="submit" className="btn btn-primary submit-receipt-btn">
                    Mədaxil Et və Maliyyədə Qeyd Et
                  </button>
                </form>
              </div>

              {/* New Category Modal */}
              {showNewCatModal && (
                <div className="modal-overlay">
                  <div className="modal-content glass-panel">
                    <h4>Yeni Kateqoriya</h4>
                    <form onSubmit={handleAddCategory}>
                      <div className="form-group">
                        <label>Kateqoriya Adı</label>
                        <input 
                          type="text" 
                          className="form-control" 
                          required 
                          value={newCatName}
                          onChange={(e) => setNewCatName(e.target.value)}
                          placeholder="Məs. Broşlar"
                        />
                      </div>
                      <div className="modal-buttons">
                        <button type="button" className="btn btn-secondary" onClick={() => setShowNewCatModal(false)}>İmtina</button>
                        <button type="submit" className="btn btn-primary">Əlavə Et</button>
                      </div>
                    </form>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 3. WAREHOUSE LIST TAB */}
          {activeTab === 'warehouse' && (
            <div className="warehouse-view animate-fade">
              <h3 className="section-title">Anbar Balansı və Qalıq</h3>
              
              <div className="table-container">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Şəkil</th>
                      <th>Məhsul</th>
                      <th>SKU</th>
                      <th>Kateqoriya</th>
                      <th>Alış (Maya)</th>
                      <th>Satış Qiyməti</th>
                      <th>Anbar Qalığı</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.map(p => {
                      let statusText = 'Normal';
                      let statusClass = 'badge-success';
                      if (p.stock === 0) {
                        statusText = 'Tükənib';
                        statusClass = 'badge-danger';
                      } else if (p.stock <= 3) {
                        statusText = 'Kritik';
                        statusClass = 'badge-danger';
                      } else if (p.stock <= 6) {
                        statusText = 'Az qalır';
                        statusClass = 'badge-warning';
                      }

                      return (
                        <tr key={p.id}>
                          <td>
                            <img src={p.image} alt={p.name} className="product-table-thumb" />
                          </td>
                          <td>
                            <strong>{p.name}</strong>
                          </td>
                          <td><code>{p.sku}</code></td>
                          <td>{p.category}</td>
                          <td>{p.purchasePrice.toFixed(2)} AZN</td>
                          <td>{p.price.toFixed(2)} AZN</td>
                          <td style={{ fontWeight: 'bold' }}>{p.stock} ədəd</td>
                          <td>
                            <span className={`badge ${statusClass}`}>{statusText}</span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 4. POS SALES TAB */}
          {activeTab === 'pos' && (
            <div className="pos-view animate-fade">
              <h3 className="section-title">POS Satış Paneli</h3>
              
              <div className="pos-layout">
                {/* Product Catalog list for POS */}
                <div className="pos-catalog">
                  <div className="form-group">
                    <input 
                      type="text" 
                      placeholder="Məhsul adı və ya SKU ilə axtar..." 
                      className="form-control pos-search"
                      value={posSearch}
                      onChange={(e) => setPosSearch(e.target.value)}
                    />
                  </div>

                  <div className="pos-product-grid">
                    {products.filter(p => 
                      p.name.toLowerCase().includes(posSearch.toLowerCase()) || 
                      p.sku.toLowerCase().includes(posSearch.toLowerCase())
                    ).map(p => (
                      <button 
                        key={p.id} 
                        className="pos-product-card glass-panel"
                        disabled={p.stock <= 0}
                        onClick={() => addToPosCart(p)}
                      >
                        <img src={p.image} alt={p.name} />
                        <div className="pos-p-info">
                          <h5>{p.name}</h5>
                          <div className="pos-p-row">
                            <span className="price">{p.price.toFixed(2)} AZN</span>
                            <span className={`stock ${p.stock <= 3 ? 'low' : ''}`}>Qalıq: {p.stock}</span>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Checkout & Bill Area */}
                <div className="pos-checkout glass-panel">
                  <h4>Cari Satış Fakturası</h4>
                  
                  {posCart.length > 0 ? (
                    <>
                      <div className="pos-cart-list">
                        {posCart.map(item => (
                          <div key={item.id} className="pos-cart-item">
                            <div className="item-info">
                              <h5>{item.name}</h5>
                              <span>{item.price.toFixed(2)} AZN</span>
                            </div>
                            <div className="item-qty">
                              <button onClick={() => updatePosQty(item.id, item.qty - 1)}>-</button>
                              <span>{item.qty}</span>
                              <button onClick={() => updatePosQty(item.id, item.qty + 1)}>+</button>
                            </div>
                            <div className="item-total">
                              <strong>{(item.price * item.qty).toFixed(2)} AZN</strong>
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="pos-summary">
                        <div className="summary-row total-row">
                          <span>Yekun Məbləğ:</span>
                          <span>{posCart.reduce((acc, i) => acc + (i.price * i.qty), 0).toFixed(2)} AZN</span>
                        </div>
                      </div>

                      <form onSubmit={handlePOSCheckout} className="pos-checkout-form">
                        <div className="form-group flex-row">
                          <label className="checkbox-label">
                            <input 
                              type="checkbox" 
                              checked={posIsDebt} 
                              onChange={(e) => setPosIsDebt(e.target.checked)} 
                            />
                            <span>Nisyə Satış (Müştərini borclandır)</span>
                          </label>
                        </div>

                        {posIsDebt && (
                          <div className="debt-fields animate-fade">
                            <div className="form-group">
                              <label>Müştəri Adı, Soyadı *</label>
                              <input 
                                type="text" 
                                className="form-control" 
                                required={posIsDebt}
                                value={posCustName}
                                onChange={(e) => setPosCustName(e.target.value)}
                                placeholder="Elnur Məmmədov"
                              />
                            </div>
                            <div className="form-group">
                              <label>Telefon Nömrəsi *</label>
                              <input 
                                type="tel" 
                                className="form-control" 
                                required={posIsDebt}
                                value={posCustPhone}
                                onChange={(e) => setPosCustPhone(e.target.value)}
                                placeholder="+994 xx xxx xx xx"
                              />
                            </div>
                            <div className="form-grid-2">
                              <div className="form-group">
                                <label>İlkin ödəniş (AZN)</label>
                                <input 
                                  type="number" 
                                  step="0.01" 
                                  className="form-control" 
                                  value={posPaidUpfront}
                                  onChange={(e) => setPosPaidUpfront(e.target.value)}
                                  placeholder="0.00"
                                />
                              </div>
                              <div className="form-group">
                                <label>Son Ödəniş Tarixi</label>
                                <input 
                                  type="date" 
                                  className="form-control" 
                                  value={posDueDate}
                                  onChange={(e) => setPosDueDate(e.target.value)}
                                />
                              </div>
                            </div>
                          </div>
                        )}

                        <button type="submit" className="btn btn-primary w-100-btn pos-btn">
                          Satışı Tamamla
                        </button>
                      </form>
                    </>
                  ) : (
                    <div className="empty-cart-message">
                      <ShoppingCart size={40} className="empty-icon" />
                      <p>Səbət boşdur.</p>
                      <p className="hint">Məhsulların üzərinə klikləyərək səbətə əlavə edin.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* 5. ORDERS TAB */}
          {activeTab === 'orders' && (
            <div className="orders-view animate-fade">
              <h3 className="section-title">Onlayn E-Commerce Sifarişləri</h3>

              <div className="table-container">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Sifariş ID</th>
                      <th>Müştəri</th>
                      <th>Telefon / Ünvan</th>
                      <th>Məhsullar</th>
                      <th>Məbləğ</th>
                      <th>Tarix</th>
                      <th>Status</th>
                      <th>Əməliyyatlar</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.map(o => (
                      <tr key={o.id}>
                        <td><code>{o.id}</code></td>
                        <td><strong>{o.customerName}</strong></td>
                        <td>
                          <div>{o.customerPhone}</div>
                          <div className="text-muted font-sm">{o.address}</div>
                        </td>
                        <td>
                          {o.items.map(i => `${i.name} (${i.qty}x)`).join(', ')}
                        </td>
                        <td><strong>{o.total.toFixed(2)} AZN</strong></td>
                        <td>{new Date(o.date).toLocaleDateString()}</td>
                        <td>
                          <span className={`badge ${
                            o.status === 'Gözləmədə' ? 'badge-warning' : 
                            o.status === 'Çatdırıldı' ? 'badge-success' : 'badge-danger'
                          }`}>{o.status}</span>
                        </td>
                        <td>
                          {o.status === 'Gözləmədə' ? (
                            <div className="action-buttons-row">
                              <button 
                                className="btn btn-primary btn-sm btn-icon" 
                                onClick={() => updateOrderStatus(o.id, 'Çatdırıldı')}
                                title="Təsdiqlə və Çatdır"
                              >
                                <Check size={16} />
                              </button>
                              <button 
                                className="btn btn-danger btn-sm btn-icon" 
                                onClick={() => updateOrderStatus(o.id, 'Ləğv edilib')}
                                title="Sifarişi Ləğv et"
                              >
                                <X size={16} />
                              </button>
                            </div>
                          ) : (
                            <span className="text-muted">-</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 6. DEBTORS TAB */}
          {activeTab === 'debtors' && (
            <div className="debtors-view animate-fade">
              <h3 className="section-title">Borclular Siyahısı (Nisyə Satışlar)</h3>

              <div className="table-container">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Müştəri</th>
                      <th>Telefon</th>
                      <th>Ümumi Borc</th>
                      <th>Qalıq Borc</th>
                      <th>Son Ödəniş Tarixi</th>
                      <th>Status</th>
                      <th>Tarixçə</th>
                      <th>Əməliyyatlar</th>
                    </tr>
                  </thead>
                  <tbody>
                    {debts.map(d => (
                      <tr key={d.id}>
                        <td><strong>{d.customerName}</strong></td>
                        <td>{d.customerPhone}</td>
                        <td>{d.totalDebt.toFixed(2)} AZN</td>
                        <td style={{ fontWeight: 'bold' }} className={d.remainingDebt > 0 ? 'text-danger' : 'text-success'}>
                          {d.remainingDebt.toFixed(2)} AZN
                        </td>
                        <td>
                          <span className="flex-center-gap">
                            <Calendar size={14} className="text-muted" />
                            {d.dueDate}
                          </span>
                        </td>
                        <td>
                          <span className={`badge ${d.status === 'Aktiv' ? 'badge-danger' : 'badge-success'}`}>
                            {d.status === 'Aktiv' ? 'Ödənilməyib' : 'Tam Ödənilib'}
                          </span>
                        </td>
                        <td>
                          <div className="payment-history-list">
                            {d.payments.length > 0 ? (
                              d.payments.map((p, idx) => (
                                <div key={p.id || idx} className="payment-history-item font-sm text-muted">
                                  <span>{new Date(p.date).toLocaleDateString()}:</span>
                                  <strong>+{p.amount.toFixed(2)} AZN</strong>
                                </div>
                              ))
                            ) : (
                              <span className="text-muted">Ödəniş yoxdur</span>
                            )}
                          </div>
                        </td>
                        <td>
                          {d.status === 'Aktiv' ? (
                            <button 
                              className="btn btn-primary btn-sm"
                              onClick={() => openDebtPaymentModal(d.id)}
                            >
                              Ödəniş Qəbul Et
                            </button>
                          ) : (
                            <span className="text-success font-semibold">Boranı Bağlıdır</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Debt payment modal */}
              {showPaymentModal && (
                <div className="modal-overlay">
                  <div className="modal-content glass-panel">
                    <h4>Borc Ödənişinin Qəbulu</h4>
                    <form onSubmit={handleRecordPayment}>
                      <div className="form-group">
                        <label>Ödənilən Məbləğ (AZN)</label>
                        <input 
                          type="number" 
                          step="0.01"
                          className="form-control" 
                          required 
                          value={paymentAmount}
                          onChange={(e) => setPaymentAmount(e.target.value)}
                          placeholder="Məs. 50.00"
                        />
                      </div>
                      <div className="modal-buttons">
                        <button type="button" className="btn btn-secondary" onClick={() => setShowPaymentModal(false)}>İmtina</button>
                        <button type="submit" className="btn btn-primary">Ödənişi Təsdiqlə</button>
                      </div>
                    </form>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 7. FINANCE & REPORTS TAB */}
          {activeTab === 'finance' && (
            <div className="finance-view animate-fade">
              <h3 className="section-title">Maliyyə Jurnalı və Xərc Qeydiyyatı</h3>

              <div className="finance-grid">
                {/* Add Expense Form */}
                <div className="card glass-panel form-card">
                  <h4>Digər Xərclərin Qeydiyyatı</h4>
                  <form onSubmit={handleAddExpense}>
                    <div className="form-group">
                      <label>Xərc Məbləği (AZN) *</label>
                      <input 
                        type="number" 
                        step="0.01" 
                        className="form-control" 
                        required 
                        value={expAmount}
                        onChange={(e) => setExpAmount(e.target.value)}
                        placeholder="Məs. 350.00"
                      />
                    </div>

                    <div className="form-group">
                      <label>Xərc Kateqoriyası *</label>
                      <select 
                        className="form-control"
                        value={expCategory}
                        onChange={(e) => setExpCategory(e.target.value)}
                      >
                        <option value="İcarə">İcarə Haqqı</option>
                        <option value="Maaş">Maaşlar</option>
                        <option value="Kommunal">Kommunal Xərclər</option>
                        <option value="Reklam">Reklam və Marketinq</option>
                        <option value="Digər">Digər Cari Xərclər</option>
                      </select>
                    </div>

                    <div className="form-group">
                      <label>Xərc Təsviri / Qeydlər</label>
                      <textarea 
                        className="form-control" 
                        rows="2"
                        value={expDesc}
                        onChange={(e) => setExpDesc(e.target.value)}
                        placeholder="Məs. May ayı icarə haqqı ödənişi"
                      ></textarea>
                    </div>

                    <button type="submit" className="btn btn-danger w-100-btn">
                      Xərci Qeyd Et
                    </button>
                  </form>
                </div>

                {/* Finance balance sheet widget */}
                <div className="card glass-panel totals-card">
                  <h4>Maliyyə Balansı</h4>
                  <div className="balance-sheet">
                    <div className="balance-row">
                      <span>Satış Gəlirləri:</span>
                      <strong className="text-success">+{totalSales.toFixed(2)} AZN</strong>
                    </div>
                    <div className="balance-row">
                      <span>Logistik/Mədaxil Xərcləri:</span>
                      <strong className="text-danger">
                        -{transactions.filter(t => t.type === 'expense' && t.category === 'Mədaxil').reduce((sum, t) => sum + t.amount, 0).toFixed(2)} AZN
                      </strong>
                    </div>
                    <div className="balance-row">
                      <span>Digər Xərclər (İcarə/Maaş və s.):</span>
                      <strong className="text-danger">
                        -{transactions.filter(t => t.type === 'expense' && t.category !== 'Mədaxil').reduce((sum, t) => sum + t.amount, 0).toFixed(2)} AZN
                      </strong>
                    </div>
                    <hr className="divider" />
                    <div className="balance-row total-row">
                      <span>Xalis Mənfəət:</span>
                      <strong className={netIncome >= 0 ? 'text-success' : 'text-danger'}>
                        {netIncome.toFixed(2)} AZN
                      </strong>
                    </div>
                  </div>
                </div>
              </div>

              {/* Full transaction list */}
              <div className="table-container mt-4">
                <div className="col-header p-3">
                  <h4>Əməliyyatların Xronologiyası (Maliyyə Jurnalı)</h4>
                </div>
                <table className="table">
                  <thead>
                    <tr>
                      <th>Tarix</th>
                      <th>Növ</th>
                      <th>Məbləğ</th>
                      <th>Kateqoriya</th>
                      <th>Təsvir</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.map(t => (
                      <tr key={t.id}>
                        <td>{new Date(t.date).toLocaleString()}</td>
                        <td>
                          <span className={`badge ${t.type === 'income' ? 'badge-success' : 'badge-danger'}`}>
                            {t.type === 'income' ? 'Mədaxil (Gəlir)' : 'Məxaric (Xərc)'}
                          </span>
                        </td>
                        <td style={{ fontWeight: 'bold' }} className={t.type === 'income' ? 'text-success' : 'text-danger'}>
                          {t.type === 'income' ? '+' : '-'}{t.amount.toFixed(2)} AZN
                        </td>
                        <td>{t.category}</td>
                        <td>{t.description}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 8. STAFF MANAGEMENT TAB */}
          {activeTab === 'staff' && (
            <div className="staff-view animate-fade">
              <h3 className="section-title">Əməkdaşlar və Rolların İdarə Edilməsi</h3>

              <div className="finance-grid">
                {/* Create user */}
                <div className="card glass-panel form-card">
                  <h4>Yeni Əməkdaş Profilinin Yaradılması</h4>
                  <form onSubmit={handleAddStaff}>
                    <div className="form-group">
                      <label>İstifadəçi adı (Giriş üçün) *</label>
                      <input 
                        type="text" 
                        className="form-control" 
                        required 
                        value={staffUser}
                        onChange={(e) => setStaffUser(e.target.value)}
                        placeholder="Məs. murad.h"
                      />
                    </div>

                    <div className="form-group">
                      <label>Əməkdaşın Adı, Soyadı *</label>
                      <input 
                        type="text" 
                        className="form-control" 
                        required 
                        value={staffName}
                        onChange={(e) => setStaffName(e.target.value)}
                        placeholder="Məs. Murad Həsənov"
                      />
                    </div>

                    <div className="form-group">
                      <label>Sistem Rolu *</label>
                      <select 
                        className="form-control"
                        value={staffRole}
                        onChange={(e) => setStaffRole(e.target.value)}
                      >
                        <option value="satici">Satıcı (POS, Sifarişlər)</option>
                        <option value="anbardar">Anbardar (Malların mədahili, Anbar)</option>
                        <option value="maliyye">Maliyyə Müdiri (Maliyyə, Borclar)</option>
                        <option value="admin">Superadmin (Tam Səlahiyyət)</option>
                      </select>
                    </div>

                    <div className="form-group">
                      <label>Giriş Şifrəsi *</label>
                      <input 
                        type="password" 
                        className="form-control" 
                        required 
                        value={staffPass}
                        onChange={(e) => setStaffPass(e.target.value)}
                        placeholder="••••••"
                      />
                    </div>

                    <button type="submit" className="btn btn-primary w-100-btn">
                      Əməkdaşı Qeyd Et
                    </button>
                  </form>
                </div>

                {/* Active user list */}
                <div className="card glass-panel">
                  <h4>Mövcud Əməkdaşlar</h4>
                  <div className="staff-list">
                    {users.map(u => (
                      <div key={u.id} className="staff-item">
                        <div className="staff-info">
                          <h5>{u.name}</h5>
                          <span>@{u.username}</span>
                          <span className="badge badge-info mt-1">{u.role.toUpperCase()}</span>
                        </div>
                        <div className="staff-actions">
                          <button 
                            className="btn btn-danger btn-icon" 
                            onClick={() => deleteUser(u.id)}
                            title="Əməkdaş profilini sil"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

        </main>
      </div>
    </div>
  );
}
