import React, { useContext, useState } from 'react';
import { AppContext } from '../context/AppContext';
import { ShoppingBag, Search, ChevronRight, CheckCircle, ArrowRight, User } from 'lucide-react';

export default function Ecommerce({ onNavigateToLogin }) {
  const { products, categories, placeEcommerceOrder } = useContext(AppContext);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Cart State
  const [cart, setCart] = useState([]);
  
  // Checkout Form State
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [address, setAddress] = useState('');
  
  const [isOrdered, setIsOrdered] = useState(false);
  const [lastOrderId, setLastOrderId] = useState('');

  // Filter products
  const filteredProducts = products.filter(p => {
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const addToCart = (product) => {
    if (product.stock <= 0) return;
    
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        if (existing.qty >= product.stock) return prev; // limit to stock
        return prev.map(item => item.id === product.id ? { ...item, qty: item.qty + 1 } : item);
      }
      return [...prev, { ...product, qty: 1 }];
    });
  };

  const updateCartQty = (productId, qty) => {
    if (qty <= 0) {
      setCart(prev => prev.filter(item => item.id !== productId));
      return;
    }
    const product = products.find(p => p.id === productId);
    if (product && qty > product.stock) return; // limit to stock

    setCart(prev => prev.map(item => item.id === productId ? { ...item, qty } : item));
  };

  const removeFromCart = (productId) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  };

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);

  const handleCheckout = (e) => {
    e.preventDefault();
    if (!customerName || !customerPhone || !address || cart.length === 0) return;

    const orderId = placeEcommerceOrder({ name: customerName, phone: customerPhone, address }, cart);
    setLastOrderId(orderId);
    setIsOrdered(true);
    setCart([]);
    setCustomerName('');
    setCustomerPhone('');
    setAddress('');
  };

  return (
    <div className="ecommerce-container">
      {/* Navbar */}
      <header className="eco-header">
        <div className="eco-nav container">
          <div className="eco-logo">
            <h1 className="logo-text">LUMIÈRE</h1>
            <span className="logo-subtext">Bujuteriya & Lüks</span>
          </div>
          <div className="eco-nav-actions">
            <button 
              id="admin-login-btn" 
              className="btn btn-secondary btn-login-nav" 
              onClick={onNavigateToLogin}
            >
              <User size={18} />
              <span>Əməkdaş Girişi</span>
            </button>
          </div>
        </div>
      </header>

      {/* Hero Banner */}
      <section className="eco-hero">
        <div className="eco-hero-overlay"></div>
        <div className="eco-hero-content container">
          <span className="hero-badge">YENİ KOLLEKSİYA</span>
          <h2>Zəriflik və Parıltı Bir Arada</h2>
          <p>Hər anınızı xüsusi edəcək eksklüziv Swarowski və gümüş bujuteriya məhsulları.</p>
          <a href="#catalog" className="btn btn-primary hero-btn">
            Kolleksiyanı Kəşf Et
            <ArrowRight size={18} />
          </a>
        </div>
      </section>

      {/* Main Content Grid */}
      <main id="catalog" className="eco-main container">
        <div className="catalog-layout">
          
          {/* Products & Filters */}
          <div className="catalog-products-side">
            
            {/* Search and Category Filter Bar */}
            <div className="filter-bar">
              <div className="search-box">
                <Search size={18} className="search-icon" />
                <input 
                  type="text" 
                  placeholder="Məhsul axtar..." 
                  className="form-control search-input"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              <div className="categories-list">
                <button 
                  className={`cat-btn ${selectedCategory === 'All' ? 'active' : ''}`}
                  onClick={() => setSelectedCategory('All')}
                >
                  Hamısı
                </button>
                {categories.map((cat) => (
                  <button 
                    key={cat} 
                    className={`cat-btn ${selectedCategory === cat ? 'active' : ''}`}
                    onClick={() => setSelectedCategory(cat)}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Product Grid */}
            <div className="product-grid">
              {filteredProducts.length > 0 ? (
                filteredProducts.map((product) => (
                  <div key={product.id} className="product-card">
                    <div className="product-image-container">
                      <img src={product.image} alt={product.name} className="product-image" />
                      {product.stock <= 0 ? (
                        <div className="sold-out-badge">TÜKƏNİB</div>
                      ) : product.stock <= 2 ? (
                        <div className="low-stock-badge">SON {product.stock} ƏDƏD</div>
                      ) : null}
                    </div>
                    <div className="product-info">
                      <span className="product-cat">{product.category}</span>
                      <h3 className="product-title">{product.name}</h3>
                      <p className="product-desc">{product.description}</p>
                      <div className="product-price-row">
                        <span className="product-price">{product.price.toFixed(2)} AZN</span>
                        <button 
                          className="btn btn-primary btn-add-cart"
                          disabled={product.stock <= 0}
                          onClick={() => addToCart(product)}
                        >
                          Səbətə At
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="no-products">
                  <p>Məhsul tapılmadı.</p>
                </div>
              )}
            </div>

          </div>

          {/* Cart Panel Side */}
          <div className="catalog-cart-side">
            <div className="cart-sticky-container glass-panel">
              <div className="cart-header">
                <ShoppingBag size={20} className="gold-text" />
                <h3>Səbətiniz</h3>
                {cart.length > 0 && <span className="cart-count-badge">{cart.length}</span>}
              </div>

              {isOrdered ? (
                <div className="order-success-screen">
                  <CheckCircle size={48} className="success-icon animate-bounce" />
                  <h4>Sifarişiniz Uğurludur!</h4>
                  <p>Sifariş Nömrəniz: <strong>{lastOrderId}</strong></p>
                  <p>Menecerlərimiz tezliklə sizinlə əlaqə saxlayacaqlar.</p>
                  <button className="btn btn-primary" onClick={() => setIsOrdered(false)}>
                    Alış-verişə Davam Et
                  </button>
                </div>
              ) : cart.length > 0 ? (
                <>
                  <div className="cart-items-list">
                    {cart.map((item) => (
                      <div key={item.id} className="cart-item">
                        <img src={item.image} alt={item.name} className="cart-item-img" />
                        <div className="cart-item-info">
                          <h5>{item.name}</h5>
                          <span className="cart-item-price">{item.price.toFixed(2)} AZN</span>
                          <div className="cart-qty-control">
                            <button onClick={() => updateCartQty(item.id, item.qty - 1)}>-</button>
                            <span>{item.qty}</span>
                            <button onClick={() => updateCartQty(item.id, item.qty + 1)}>+</button>
                          </div>
                        </div>
                        <button className="btn-remove-item" onClick={() => removeFromCart(item.id)}>×</button>
                      </div>
                    ))}
                  </div>

                  <div className="cart-summary">
                    <div className="summary-row">
                      <span>Cəm</span>
                      <span>{cartTotal.toFixed(2)} AZN</span>
                    </div>
                    <div className="summary-row">
                      <span>Çatdırılma</span>
                      <span className="success-text">Ödənişsiz</span>
                    </div>
                    <div className="summary-row total-row">
                      <span>Yekun</span>
                      <span>{cartTotal.toFixed(2)} AZN</span>
                    </div>
                  </div>

                  <form className="checkout-form" onSubmit={handleCheckout}>
                    <h4>Çatdırılma Məlumatları</h4>
                    <div className="form-group">
                      <input 
                        type="text" 
                        placeholder="Adınız və Soyadınız" 
                        className="form-control" 
                        required
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                      />
                    </div>
                    <div className="form-group">
                      <input 
                        type="tel" 
                        placeholder="Telefon Nömrəniz (+994...)" 
                        className="form-control" 
                        required
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                      />
                    </div>
                    <div className="form-group">
                      <textarea 
                        placeholder="Çatdırılma Ünvanı" 
                        className="form-control" 
                        rows="2"
                        required
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                      ></textarea>
                    </div>
                    <button type="submit" className="btn btn-primary w-100-btn">
                      Sifarişi Tamamla
                    </button>
                  </form>
                </>
              ) : (
                <div className="empty-cart-message">
                  <ShoppingBag size={40} className="empty-icon" />
                  <p>Səbətiniz boşdur.</p>
                  <p className="hint">Məhsulların yanındakı "Səbətet At" düyməsindən istifadə edin.</p>
                </div>
              )}
            </div>
          </div>

        </div>
      </main>

      {/* Footer */}
      <footer className="eco-footer">
        <div className="container">
          <p>© 2026 LUMIÈRE. Bütün hüquqlar qorunur.</p>
          <p className="footer-credits">Bujuteriya və Aksessuarların Satışı və Logistik İdarəetmə Portalı.</p>
        </div>
      </footer>
    </div>
  );
}
