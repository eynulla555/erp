import React, { useState, useContext } from 'react';
import { AppContext } from '../context/AppContext';
import { Shield, Key, User, ArrowLeft } from 'lucide-react';

export default function Login({ onLoginSuccess, onNavigateBack }) {
  const { login } = useContext(AppContext);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!username || !password) {
      setError('Zəhmət olmasa bütün sahələri doldurun.');
      return;
    }

    const res = login(username, password);
    if (res.success) {
      onLoginSuccess(res.user);
    } else {
      setError('Giriş məlumatları yanlışdır.');
    }
  };

  const handleDemoLogin = (userType) => {
    setUsername(userType);
    setPassword('123');
    const res = login(userType, '123');
    if (res.success) {
      onLoginSuccess(res.user);
    }
  };

  return (
    <div className="login-page">
      <div className="login-overlay"></div>
      
      <div className="login-content">
        <button className="btn btn-secondary back-to-store" onClick={onNavigateBack}>
          <ArrowLeft size={16} />
          <span>Vitrinə Qayıt</span>
        </button>

        <div className="login-card glass-panel">
          <div className="login-header">
            <div className="shield-icon-container">
              <Shield size={32} className="gold-text animate-pulse" />
            </div>
            <h2>LUMIÈRE ERP Portal</h2>
            <p>Əməkdaşların idarəetmə panelinə giriş</p>
          </div>

          {error && <div className="login-error-msg">{error}</div>}

          <form onSubmit={handleSubmit} className="login-form">
            <div className="form-group">
              <label htmlFor="username">İstifadəçi adı</label>
              <div className="input-with-icon">
                <User size={18} className="input-icon" />
                <input 
                  id="username"
                  type="text" 
                  className="form-control" 
                  placeholder="İstifadəçi adını daxil edin"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="password">Şifrə</label>
              <div className="input-with-icon">
                <Key size={18} className="input-icon" />
                <input 
                  id="password"
                  type="password" 
                  className="form-control" 
                  placeholder="Şifrəni daxil edin"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
            </div>

            <button type="submit" className="btn btn-primary login-submit-btn">
              Daxil Ol
            </button>
          </form>

          {/* Quick Access Credentials */}
          <div className="quick-access-box">
            <h4>Sürətli Giriş (Demo Profil Seçin):</h4>
            <div className="demo-users-grid">
              <button onClick={() => handleDemoLogin('admin')} className="demo-user-btn admin">
                <strong>Admin</strong>
                <span>Rəşad Əliyev</span>
              </button>
              <button onClick={() => handleDemoLogin('satici')} className="demo-user-btn satici">
                <strong>Satıcı</strong>
                <span>Leyla M.</span>
              </button>
              <button onClick={() => handleDemoLogin('anbardar')} className="demo-user-btn anbar">
                <strong>Anbardar</strong>
                <span>Kamil H.</span>
              </button>
              <button onClick={() => handleDemoLogin('maliyye')} className="demo-user-btn maliyye">
                <strong>Maliyyə</strong>
                <span>Nigar Q.</span>
              </button>
            </div>
            <p className="demo-password-hint">Bütün demo profillər üçün şifrə: <strong>123</strong></p>
          </div>
        </div>
      </div>
    </div>
  );
}
